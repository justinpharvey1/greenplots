#config file containing credentials for rds mysql instance
db_username = "greenplots"
db_password = "Greenplots1"
db_name = "greenplotsdb" 